using System;
using System.Text.RegularExpressions;

class MainClass {
  public static int[] koordy(int[,] stan){

  Console.WriteLine("wpisz koordy karty - x, y. liczbami");
    int x=0;
    int y=0;
   string tmp = Console.ReadLine();
            if (Regex.IsMatch(tmp, @"^\d+$"))
                x = Int32.Parse(tmp);
            else
                {Console.WriteLine("no brawo zepsułeś");
              
                }
    tmp = Console.ReadLine();
            if (Regex.IsMatch(tmp, @"^\d+$"))
                y = Int32.Parse(tmp);
            else
                {Console.WriteLine("no brawo zepsułeś");
                
                }
   if (stan[x,y]==1) Console.WriteLine("odsłonięta");
   else if (stan[x,y]==2) Console.WriteLine("zgadnięta");
   else if (stan[x,y]==0) Console.WriteLine("ok");
   else Console.WriteLine("raczej błąd");
   int[] t= new int[]{x-1, y-1};
     return t;
   
  }
  public static void wypisz (int[,] stan, string[,] memory){
                  for(int i=0; i<6; i++) {
      for(int j=0; j<6; j++) {
        if (stan[j,i]==1) Console.Write(memory[j,i]);
        else if (stan[j,i]==2) Console.Write("   ");
        else Console.Write(" ⬜ ");}
      Console.WriteLine();
    }
  }
  public static void Main (string[] args) {
    /*
    //Deklaracja odsłoniętych kart
    string[,] memoryBoard 
    = new string[2,2] {{" 🤣 ", " 😅 "},
                       {" 🤣 ", " 😅 "}};


    //Deklaracja zakrytych kart (posłużą do ukrycia zawartości)
    string[,] memoryHiddenBoard 
    = new string[2,2] {{" ❌ ", " ❌ "},
                       {" ❌ ", " ❌ "}};
                           //Wyświetlanie wszystkich odkrytych
    for (int rowIndex = 0; rowIndex < memoryBoard.GetLength(0); rowIndex++) {
      for (int columnIndex = 0; columnIndex < memoryBoard.GetLength(1); columnIndex++) {
        Console.Write(memoryBoard[rowIndex, columnIndex]);
      }
      Console.WriteLine();
    }
*/
int[,] stan = new int[6,6]{{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0}};
int[,] cel = new int[6,6]{{2,2,2,2,2,2},{2,2,2,2,2,2},{2,2,2,2,2,2},{2,2,2,2,2,2},{2,2,2,2,2,2},{2,2,2,2,2,2}};
//niezgadnięte = 0, odsłonięte = 1, zgadnięte = 2

string[,] memory = new string[6,6] {{" 🤠 "," 👌 "," 💣 "," 🍓 "," 🙏 "," 😡 "},{" 💚 "," 🥓 "," 🧲 "," 🐮 "," 🎱 "," 🍆 "},{" 💚 "," 🍇 "," 🦙 "," 🍇 "," 🙈 "," 🐲 "},{" 🐄 "," 👌 "," 🚑 "," 🙏 "," 🤠 "," 🦙 "},{" 🍓 "," 🍆 "," 🙈 "," 🐄 "," 🐮 "," 🥓 "},{" 🐲 "," 💣 "," 😡 "," 🎱 "," 🚑 "," 🧲 "}};
int[] k1 = new int[]{0,0};
int[] k2 = new int[]{0,0};

              for(int i=0; i<6; i++) {
      for(int j=0; j<6; j++) {
        if (stan[j,i]==1) Console.Write(memory[j,i]);
        else if (stan[j,i]==2) Console.Write("   ");
        else Console.Write(" ⬜ ");}
      Console.WriteLine();
    }
    while (stan != cel){
    k1 = koordy(stan);
    if (stan[k1[0],k1[1]]==0) stan[k1[0],k1[1]]=1;
    wypisz(stan, memory);
    k2 = koordy(stan);
    if (stan[k2[0],k2[1]]==0) stan[k2[0],k2[1]]=1;
    wypisz(stan, memory);
    if (memory[k1[0],k1[1]]==memory[k2[0],k2[1]]){
      Console.WriteLine("zgadnięte!!!");
      stan[k1[0],k1[1]]=2;
      stan[k2[0],k2[1]]=2;
    }
    else{
     stan[k1[0],k1[1]]=0;
     stan[k2[0],k2[1]]=0;
    }}
Console.WriteLine("!!!!!!!wygrałeś!!!!!!");

// "🤠" "😡" "🙈" "💚" "💣" "🍓" "👌" "🙏" "🥓" "🐮" "🐄" "🐲" "🦙" "🍆" "🍇" " 🎱 " " 🚑 " " 🧲 "
  }

}